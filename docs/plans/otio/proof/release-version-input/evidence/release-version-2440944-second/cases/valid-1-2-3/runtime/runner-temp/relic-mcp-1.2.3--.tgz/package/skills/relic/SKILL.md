# Fixture skill
