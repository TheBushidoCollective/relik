/* fixture placeholder; never executed */
